/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import email.EmailSender;
import model.bean.Usuario;
import model.dao.UsuarioDAO;
import javax.swing.JFrame;  
import javax.swing.JInternalFrame;  
/**
 *
 * @author USER
 */
public class ConfirmarEmail extends javax.swing.JFrame {
   private String nome,ra,email,senha,codigo;
    private LoginCadastro login;
    public ConfirmarEmail() {
        initComponents();
        
        
    }

    public void enviaPalavra(LoginCadastro login,String nome,String ra,String email,String senha,String codigo){
    this.nome=nome;
    this.ra=ra;
    this.email=email;
    this.senha=senha;
    this.codigo=codigo;
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        campoConfirmacao = new javax.swing.JTextField();
        buttonConfirmar = new javax.swing.JButton();
        buttonNaoRecebi = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(204, 204, 255));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel1.setText("Enviamos um E-mail de confirmação");

        campoConfirmacao.setText("Código de confirmação");
        campoConfirmacao.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                campoConfirmacaoKeyTyped(evt);
            }
        });

        buttonConfirmar.setText("Confirmar");
        buttonConfirmar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                buttonConfirmarMouseClicked(evt);
            }
        });

        buttonNaoRecebi.setText("Não recebi o E-mail");
        buttonNaoRecebi.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                buttonNaoRecebiMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(campoConfirmacao)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 309, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(buttonConfirmar, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(buttonNaoRecebi)
                .addGap(20, 20, 20))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(campoConfirmacao, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 49, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(buttonConfirmar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(buttonNaoRecebi, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    boolean  controleCodigo=false;
    private void campoConfirmacaoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_campoConfirmacaoKeyTyped
       if(controleCodigo==false){
       campoConfirmacao.setText("");
       controleCodigo=true;
       }
    }//GEN-LAST:event_campoConfirmacaoKeyTyped

    private void buttonNaoRecebiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonNaoRecebiMouseClicked
        
        EmailSender es=new EmailSender();
        es.enviar(codigo, email);
        
    }//GEN-LAST:event_buttonNaoRecebiMouseClicked

    private void buttonConfirmarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonConfirmarMouseClicked
         
        UsuarioDAO dao=new UsuarioDAO();
        String conf=campoConfirmacao.getText();
        if(codigo.equals(conf)){
            Usuario u=new Usuario();
            u.setNome(nome);
            u.setRa(ra);
            u.setEmail(email);
            u.setSenha(senha);
            dao.CadastroInic(u);
            this.dispose();
            
        }else
            campoConfirmacao.setText("Código invalido!!!");
        
    }//GEN-LAST:event_buttonConfirmarMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ConfirmarEmail.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ConfirmarEmail.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ConfirmarEmail.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ConfirmarEmail.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ConfirmarEmail().setVisible(true);
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton buttonConfirmar;
    private javax.swing.JButton buttonNaoRecebi;
    private javax.swing.JTextField campoConfirmacao;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}
