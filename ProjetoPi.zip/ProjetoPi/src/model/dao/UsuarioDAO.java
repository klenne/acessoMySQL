/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;

import connection.ConnectionFactory;
import java.sql.Connection;
import model.bean.Usuario;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class UsuarioDAO {
    public void CadastroInic(Usuario u){
         Connection con = ConnectionFactory.getConnection();
        
        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("INSERT INTO usuario (ra,nome,email,senha)VALUES(?,?,?,?)");
            stmt.setString(1,u.getRa());
            stmt.setString(2,u.getNome());
            stmt.setString(3,u.getEmail());
            stmt.setString(4,u.getSenha());
            stmt.executeUpdate();

          
        } catch (SQLException ex) {
            System.out.println(ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }
        
    }
    
    public boolean emailValido(String email) throws SQLException{
        boolean validar=true;
        Connection con = ConnectionFactory.getConnection();
        String sql="select Count(email)as totalemails from usuario where email=?";
        PreparedStatement stmt=con.prepareStatement(sql);
        stmt.setString(1,email);
        ResultSet  rs= stmt.executeQuery();
        rs.next();
        String result=rs.getString("totalemails");
        if(result.equals("1"))
         validar=false;
        ConnectionFactory.closeConnection(con,stmt);
        return validar;
        }
        
    public boolean raValido(String ra) throws SQLException{
        boolean validar=true;
        Connection con = ConnectionFactory.getConnection();
        String sql="select Count(ra)as totalra from usuario where ra=?";
        PreparedStatement stmt=con.prepareStatement(sql);
        stmt.setString(1,ra);
        ResultSet  rs= stmt.executeQuery();
        rs.next();
        String result=rs.getString("totalra");
        if(result.equals("1"))
         validar=false;
        ConnectionFactory.closeConnection(con,stmt);
        return validar;
        }
    }
    
    


